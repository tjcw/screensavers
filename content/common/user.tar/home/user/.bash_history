cp .face face
